class SemanticException(Exception):
    pass