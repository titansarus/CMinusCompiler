class SemanticException(Exception):
    pass
